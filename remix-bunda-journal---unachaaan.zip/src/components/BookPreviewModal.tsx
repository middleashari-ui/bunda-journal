import React, { useState } from 'react';
import { PhotoMemory, UserProfile } from '../types';
import { X, ChevronLeft, ChevronRight, Sparkles, Download, Check } from 'lucide-react';

interface BookPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile;
  photos: PhotoMemory[];
  journalText: string;
  week: number;
}

export const BookPreviewModal: React.FC<BookPreviewModalProps> = ({
  isOpen,
  onClose,
  userProfile,
  photos,
  journalText,
  week,
}) => {
  const [currentPage, setCurrentPage] = useState(0);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  if (!isOpen) return null;

  const totalPages = 4;

  const handleDownload = () => {
    setDownloadSuccess(true);
    const prev = document.title;
    document.title = `Pratinjau_Buku_Kenangan_B5_${(userProfile?.name || 'Bunda').replace(/\s+/g, '_')}`;
    setTimeout(() => {
      window.print();
      setTimeout(() => {
        document.title = prev;
        setDownloadSuccess(false);
      }, 1200);
    }, 250);
  };

  const currentPhoto = photos[0] || {
    caption: 'USG Trimester 1 (12W)',
    date: '12 Okt 2024',
    src: 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=600&q=80',
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div className="bg-[#FAF8F5] rounded-3xl max-w-xl w-full p-4 sm:p-6 shadow-2xl border border-stone-300 relative flex flex-col max-h-[92vh]">
        {/* Top Control Bar */}
        <div className="flex items-center justify-between pb-3 border-b border-stone-200">
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase tracking-widest text-[#556B2F] font-semibold">
              Pratinjau Buku Cetak Linen
            </span>
            <span className="text-[10px] bg-stone-200 px-2 py-0.5 rounded-full text-stone-600">
              Halaman {currentPage + 1} / {totalPages}
            </span>
          </div>
          <button 
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-stone-200/80 hover:bg-stone-300 flex items-center justify-center text-stone-700 cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Book Sheet Container (Simulating authentic paper & linen texture) */}
        <div className="my-auto py-4 flex items-center justify-center">
          <div className="w-full max-w-md aspect-[4/5] bg-white rounded-2xl shadow-xl border border-stone-200/80 p-6 sm:p-8 flex flex-col justify-between relative overflow-hidden transition-all duration-300">
            {/* Paper Texture Overlay */}
            <div className="absolute inset-0 bg-radial from-amber-50/20 via-transparent to-stone-200/20 pointer-events-none" />

            {/* Page 0: Front Cover */}
            {currentPage === 0 && (
              <div className="flex flex-col items-center justify-center h-full text-center border-4 border-[#556B2F]/20 p-6 rounded-xl bg-[#556B2F] text-amber-100 shadow-inner">
                <span className="text-xs tracking-widest uppercase font-mono text-amber-200/70 mb-4">
                  Koleksi Kenangan Kehamilan
                </span>
                <h1 className="font-serif text-2xl sm:text-3xl font-bold tracking-tight text-white mb-2 leading-tight">
                  Surat Pertama untuk Malaikat Kecilku
                </h1>
                <div className="w-12 h-0.5 bg-amber-300/40 my-3" />
                <p className="font-serif italic text-sm text-amber-100/90 mb-6">
                  {userProfile.name}
                </p>
                <span className="text-[10px] text-amber-200/60 uppercase tracking-widest mt-auto font-mono">
                  Hardcover Linen Asli • Cetakan Khusus
                </span>
              </div>
            )}

            {/* Page 1: Dedication & Gestational Milestone */}
            {currentPage === 1 && (
              <div className="flex flex-col justify-between h-full text-center">
                <div className="pt-2">
                  <span className="text-[10px] uppercase tracking-widest text-[#556B2F] font-semibold block mb-1">
                    Trimester Pertama • Minggu ke-12
                  </span>
                  <h2 className="font-serif text-xl font-bold text-stone-850">
                    Awal Mula Detak Kehidupan
                  </h2>
                </div>

                <div className="py-4 my-auto">
                  <span className="text-5xl block mb-2">🍋</span>
                  <p className="font-serif italic text-sm text-stone-700 max-w-xs mx-auto leading-relaxed">
                    "Wajah manismu mulai terbentuk anggun dalam keheningan rahim bunda..."
                  </p>
                </div>

                <div className="border-t border-stone-100 pt-3 grid grid-cols-3 text-center text-stone-600 text-[10px]">
                  <div>
                    <span className="block text-stone-400">Panjang</span>
                    <span className="font-serif font-bold text-stone-800 text-xs">5.4 cm</span>
                  </div>
                  <div>
                    <span className="block text-stone-400">Detak Jantung</span>
                    <span className="font-serif font-bold text-stone-800 text-xs">155 bpm</span>
                  </div>
                  <div>
                    <span className="block text-stone-400">HPL</span>
                    <span className="font-serif font-bold text-[#C87A64] text-xs">{userProfile.hplDate}</span>
                  </div>
                </div>
              </div>
            )}

            {/* Page 2: Ultrasound Photo Spread */}
            {currentPage === 2 && (
              <div className="flex flex-col justify-between h-full">
                <div className="text-center pb-2 border-b border-stone-100">
                  <span className="text-[10px] uppercase tracking-wider text-stone-400 font-medium">
                    Dokumentasi Ultrasonografi
                  </span>
                  <h3 className="font-serif text-sm font-bold text-stone-800">
                    {currentPhoto.caption}
                  </h3>
                </div>

                <div className="my-auto rounded-xl overflow-hidden border-2 border-stone-200/80 shadow-md max-h-52 bg-black flex items-center justify-center">
                  <img 
                    src={currentPhoto.src} 
                    alt={currentPhoto.caption} 
                    className="max-h-52 w-full object-cover"
                  />
                </div>

                <div className="text-center pt-2">
                  <p className="font-serif italic text-[11px] text-stone-500">
                    Diabadikan pada {currentPhoto.date} bersama {userProfile.doctorName}
                  </p>
                </div>
              </div>
            )}

            {/* Page 3: Mother's Journal Notes */}
            {currentPage === 3 && (
              <div className="flex flex-col justify-between h-full">
                <div>
                  <span className="text-[10px] uppercase tracking-widest text-[#C87A64] font-semibold block">
                    Curahan Hati Bunda
                  </span>
                  <h3 className="font-serif text-lg font-bold text-stone-800 mt-0.5">
                    Surat Cinta Hari ke-84
                  </h3>
                </div>

                <div className="my-auto py-2">
                  <p className="font-serif italic text-stone-700 text-xs sm:text-sm leading-relaxed whitespace-pre-wrap first-letter:text-2xl first-letter:font-bold first-letter:mr-1 first-letter:float-left first-letter:text-[#556B2F]">
                    {journalText || 'Hari ini detak jantungmu terdengar begitu jelas saat kontrol dokter. Bahagia dan haru sekali, nak...'}
                  </p>
                </div>

                <div className="border-t border-stone-100 pt-3 flex justify-between items-center text-[10px] text-stone-400">
                  <span>Dicetak di Atas Kertas Fine Art Bebas Asam</span>
                  <span className="font-serif italic text-stone-600">Bunda Jessica</span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Bottom Navigation Buttons */}
        <div className="pt-3 border-t border-stone-200 flex items-center justify-between text-xs">
          <button 
            disabled={currentPage === 0}
            onClick={() => setCurrentPage(p => p - 1)}
            className={`px-3 py-1.5 rounded-xl border flex items-center gap-1 transition-colors cursor-pointer ${
              currentPage === 0 
                ? 'opacity-40 cursor-not-allowed border-stone-200' 
                : 'border-stone-300 hover:bg-stone-200 text-stone-700'
            }`}
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Sebelumnya</span>
          </button>

          <button
            onClick={handleDownload}
            className="px-3 py-1.5 bg-stone-200 hover:bg-stone-300 text-stone-800 rounded-xl font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            {downloadSuccess ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span>Pratinjau Diunduh!</span>
              </>
            ) : (
              <>
                <Download className="w-3.5 h-3.5 text-[#556B2F]" />
                <span>Simpan PDF Sample</span>
              </>
            )}
          </button>

          <button 
            disabled={currentPage === totalPages - 1}
            onClick={() => setCurrentPage(p => p + 1)}
            className={`px-3 py-1.5 rounded-xl border flex items-center gap-1 transition-colors cursor-pointer ${
              currentPage === totalPages - 1 
                ? 'opacity-40 cursor-not-allowed border-stone-200' 
                : 'border-stone-300 hover:bg-stone-200 text-stone-700'
            }`}
          >
            <span>Berikutnya</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
