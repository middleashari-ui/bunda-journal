import React, { useState, useEffect } from 'react';
import { 
  BookThemeId, 
  BOOK_THEMES, 
  BOOK_CHAPTERS 
} from '../../types/bookPrint';
import { UserProfile, PhotoMemory, JournalEntry } from '../../types';
import { IntroPages } from './pages/IntroPages';
import { Bab1AwalMula } from './pages/Bab1AwalMula';
import { PembatasTrimester } from './pages/PembatasTrimester';
import { WeeklyJournalSpread } from './pages/WeeklyJournalSpread';
import { Bab3Persiapan } from './pages/Bab3Persiapan';
import { Bab4Kelahiran } from './pages/Bab4Kelahiran';
import { Bab5KapsulWaktu } from './pages/Bab5KapsulWaktu';
import { 
  Printer, 
  Palette, 
  ChevronLeft, 
  ChevronRight, 
  BookOpen, 
  ZoomIn, 
  ZoomOut, 
  X,
  Layers,
  FileText,
  Menu,
  ChevronUp,
  Maximize2,
  Download
} from 'lucide-react';

interface PrintBookStudioProps {
  userProfile: UserProfile;
  photos: PhotoMemory[];
  pastEntries: JournalEntry[];
  currentWeek: number;
  onClose: () => void;
}

export const PrintBookStudio: React.FC<PrintBookStudioProps> = ({
  userProfile,
  photos,
  pastEntries,
  currentWeek,
  onClose,
}) => {
  // Theme state
  const [selectedThemeId, setSelectedThemeId] = useState<BookThemeId>('kinfolk-sage');
  const activeTheme = BOOK_THEMES[selectedThemeId];

  // Navigation state (0 to 49 spreads = 100 pages)
  const [currentSpreadIndex, setCurrentSpreadIndex] = useState<number>(0);
  const [isFillMode, setIsFillMode] = useState<boolean>(true);
  
  // Mobile page display mode: 'left' | 'right' | 'both'
  const [mobilePageView, setMobilePageView] = useState<'left' | 'right' | 'both'>('left');
  const [isMobile, setIsMobile] = useState<boolean>(() => {
    return typeof window !== 'undefined' ? window.innerWidth < 768 : false;
  });
  
  // Zoom scale for desktop; on mobile screen it stays 1 (fluid responsive fit)
  const [zoomScale, setZoomScale] = useState<number>(0.85);

  const [printAllMode, setPrintAllMode] = useState<boolean>(false);
  const [customPhotos, setCustomPhotos] = useState<Record<number, PhotoMemory>>({});
  
  // Drawer / Hamburger modal states
  const [isMenuOpen, setIsMenuOpen] = useState<boolean>(false);
  const [isBottomChapterOpen, setIsBottomChapterOpen] = useState<boolean>(false);

  // Auto-adapt mobilePageView on screen resize
  useEffect(() => {
    const handleResize = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
      if (mobile && mobilePageView === 'both') {
        setMobilePageView('left');
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [mobilePageView]);

  const handleUpdatePhoto = (w: number, newPhoto: PhotoMemory) => {
    setCustomPhotos(prev => ({ ...prev, [w]: newPhoto }));
  };

  const getSpreadInfo = (spreadIdx: number) => {
    const leftPage = spreadIdx * 2 + 1;
    const rightPage = spreadIdx * 2 + 2;

    if (spreadIdx === 0) {
      return {
        type: 'intro',
        chapterTitle: 'Halaman Judul & Pengantar',
        pages: [leftPage, rightPage],
      };
    }
    if (spreadIdx === 1) {
      return {
        type: 'bab1-a',
        chapterTitle: 'Bab 1: Awal Mula Kisah (Test Pack & Reaksi Ayah)',
        pages: [leftPage, rightPage],
      };
    }
    if (spreadIdx === 2) {
      return {
        type: 'bab1-b',
        chapterTitle: 'Bab 1: Awal Mula Kisah (USG Kantung Janin & Ngidam)',
        pages: [leftPage, rightPage],
      };
    }
    if (spreadIdx === 3) {
      return {
        type: 'pembatas-1',
        chapterTitle: 'Pembatas Trimester 1 (Minggu 1 - 13)',
        pages: [leftPage, rightPage],
      };
    }
    if (spreadIdx >= 4 && spreadIdx <= 12) {
      const weekNum = 5 + (spreadIdx - 4);
      return {
        type: 'weekly',
        week: weekNum,
        chapterTitle: `Bab 2: Jurnal Kehamilan (Week ${weekNum})`,
        pages: [leftPage, rightPage],
      };
    }
    if (spreadIdx === 13) {
      return {
        type: 'pembatas-2',
        chapterTitle: 'Pembatas Trimester 2 (Minggu 14 - 27)',
        pages: [leftPage, rightPage],
      };
    }
    if (spreadIdx >= 14 && spreadIdx <= 27) {
      const weekNum = 14 + (spreadIdx - 14);
      return {
        type: 'weekly',
        week: weekNum,
        chapterTitle: `Bab 2: Jurnal Kehamilan (Week ${weekNum})`,
        pages: [leftPage, rightPage],
      };
    }
    if (spreadIdx === 28) {
      return {
        type: 'pembatas-3',
        chapterTitle: 'Pembatas Trimester 3 (Minggu 28 - 40)',
        pages: [leftPage, rightPage],
      };
    }
    if (spreadIdx >= 29 && spreadIdx <= 41) {
      const weekNum = 28 + (spreadIdx - 29);
      return {
        type: 'weekly',
        week: weekNum,
        chapterTitle: `Bab 2: Jurnal Kehamilan (Week ${weekNum})`,
        pages: [leftPage, rightPage],
      };
    }
    if (spreadIdx === 42) {
      return {
        type: 'bab3-a',
        chapterTitle: 'Bab 3: Persiapan (Nama & Kamar)',
        pages: [leftPage, rightPage],
      };
    }
    if (spreadIdx === 43) {
      return {
        type: 'bab3-b',
        chapterTitle: 'Bab 3: Persiapan (Daftar Belanja Bayi)',
        pages: [leftPage, rightPage],
      };
    }
    if (spreadIdx === 44) {
      return {
        type: 'bab3-c',
        chapterTitle: 'Bab 3: Persiapan (Checklist Tas RS)',
        pages: [leftPage, rightPage],
      };
    }
    if (spreadIdx === 45) {
      return {
        type: 'bab4-a',
        chapterTitle: 'Bab 4: Kelahiran (Hari Persalinan)',
        pages: [leftPage, rightPage],
      };
    }
    if (spreadIdx === 46) {
      return {
        type: 'bab4-b',
        chapterTitle: 'Bab 4: Kelahiran (Biodata & Cap Kaki)',
        pages: [leftPage, rightPage],
      };
    }
    if (spreadIdx === 47) {
      return {
        type: 'bab4-c',
        chapterTitle: 'Bab 4: Kelahiran (Gelang RS & Foto)',
        pages: [leftPage, rightPage],
      };
    }
    if (spreadIdx === 48) {
      return {
        type: 'bab5-a',
        chapterTitle: 'Bab 5: Kapsul Waktu (Surat Bunda)',
        pages: [leftPage, rightPage],
      };
    }
    return {
      type: 'bab5-b',
      chapterTitle: 'Bab 5: Kapsul Waktu (Surat Ayah)',
      pages: [leftPage, rightPage],
    };
  };

  const renderSpreadContent = (spreadIdx: number) => {
    const info = getSpreadInfo(spreadIdx);
    const leftNum = info.pages[0];
    const rightNum = info.pages[1];

    if (info.type === 'intro') {
      return <IntroPages theme={activeTheme} userProfile={userProfile} isFillMode={isFillMode} />;
    }
    if (info.type === 'bab1-a') {
      return <Bab1AwalMula theme={activeTheme} userProfile={userProfile} photos={photos} isFillMode={isFillMode} spreadIndex={0} />;
    }
    if (info.type === 'bab1-b') {
      return <Bab1AwalMula theme={activeTheme} userProfile={userProfile} photos={photos} isFillMode={isFillMode} spreadIndex={1} />;
    }
    if (info.type === 'pembatas-1') {
      return <PembatasTrimester trimester={1} theme={activeTheme} leftPageNum={leftNum} rightPageNum={rightNum} />;
    }
    if (info.type === 'pembatas-2') {
      return <PembatasTrimester trimester={2} theme={activeTheme} leftPageNum={leftNum} rightPageNum={rightNum} />;
    }
    if (info.type === 'pembatas-3') {
      return <PembatasTrimester trimester={3} theme={activeTheme} leftPageNum={leftNum} rightPageNum={rightNum} />;
    }
    if (info.type === 'weekly') {
      const w = info.week || 12;
      const matchedEntry = pastEntries.find(e => e.week === w);
      const matchedPhoto = customPhotos[w] || photos.find(p => p.week === w);
      return (
        <WeeklyJournalSpread 
          key={`weekly-spread-${w}`}
          week={w}
          theme={activeTheme}
          leftPageNum={leftNum}
          rightPageNum={rightNum}
          journalEntry={matchedEntry}
          photo={matchedPhoto}
          isFillMode={isFillMode}
          onUpdatePhoto={handleUpdatePhoto}
        />
      );
    }
    if (info.type === 'bab3-a') {
      return <Bab3Persiapan theme={activeTheme} spreadIndex={0} leftPageNum={leftNum} rightPageNum={rightNum} isFillMode={isFillMode} />;
    }
    if (info.type === 'bab3-b') {
      return <Bab3Persiapan theme={activeTheme} spreadIndex={1} leftPageNum={leftNum} rightPageNum={rightNum} isFillMode={isFillMode} />;
    }
    if (info.type === 'bab3-c') {
      return <Bab3Persiapan theme={activeTheme} spreadIndex={2} leftPageNum={leftNum} rightPageNum={rightNum} isFillMode={isFillMode} />;
    }
    if (info.type === 'bab4-a') {
      return <Bab4Kelahiran theme={activeTheme} spreadIndex={0} leftPageNum={leftNum} rightPageNum={rightNum} userProfile={userProfile} isFillMode={isFillMode} />;
    }
    if (info.type === 'bab4-b') {
      return <Bab4Kelahiran theme={activeTheme} spreadIndex={1} leftPageNum={leftNum} rightPageNum={rightNum} userProfile={userProfile} isFillMode={isFillMode} />;
    }
    if (info.type === 'bab4-c') {
      return <Bab4Kelahiran theme={activeTheme} spreadIndex={2} leftPageNum={leftNum} rightPageNum={rightNum} userProfile={userProfile} isFillMode={isFillMode} />;
    }
    if (info.type === 'bab5-a') {
      return <Bab5KapsulWaktu theme={activeTheme} spreadIndex={0} leftPageNum={leftNum} rightPageNum={rightNum} userProfile={userProfile} isFillMode={isFillMode} />;
    }
    return <Bab5KapsulWaktu theme={activeTheme} spreadIndex={1} leftPageNum={leftNum} rightPageNum={rightNum} userProfile={userProfile} isFillMode={isFillMode} />;
  };

  const handleTriggerPrint = (printAll: boolean) => {
    const prevTitle = document.title;
    document.title = printAll 
      ? `Buku_Kenangan_Kehamilan_B5_100_Halaman_${(userProfile?.name || 'Bunda').replace(/\s+/g, '_')}`
      : `Buku_Kehamilan_B5_Hal_${currentInfo.pages[0]}-${currentInfo.pages[1]}`;
    setPrintAllMode(printAll);
    setTimeout(() => {
      window.print();
      setTimeout(() => {
        document.title = prevTitle;
      }, 1200);
    }, 350);
  };

  const currentInfo = getSpreadInfo(currentSpreadIndex);
  const activeSinglePageNum = mobilePageView === 'right' ? currentInfo.pages[1] : currentInfo.pages[0];

  return (
    <div className="print-modal-container fixed inset-0 z-50 bg-[#1E1C1A] text-stone-800 flex flex-col overflow-hidden print:static print:bg-white print:overflow-visible print:w-[176mm] print:h-auto">
      {/* ============================================================== */}
      {/* 1. TOP HEADER: SLIM & ULTRA-COMPACT FOR MOBILE READABILITY     */}
      {/* ============================================================== */}
      <header className="px-3 py-1.5 sm:px-4 sm:py-2 bg-stone-900 border-b border-stone-800 text-white flex items-center justify-between shrink-0 print:hidden z-20">
        {/* Left: Close Button & Slim Brand Logo */}
        <div className="flex items-center gap-2">
          <button 
            onClick={onClose}
            className="w-7 h-7 rounded-lg bg-stone-800 hover:bg-stone-700 flex items-center justify-center text-stone-300 hover:text-white transition-colors cursor-pointer"
            title="Tutup Studio"
          >
            <X className="w-3.5 h-3.5" />
          </button>
          <div className="flex items-baseline gap-1.5">
            <span className="font-serif font-bold text-sm text-stone-100">bunda.</span>
            <span className="text-[10px] text-amber-200/90 font-mono bg-stone-800 px-1.5 py-0.2 rounded-sm">
              B5 • Hal {mobilePageView === 'both' ? `${currentInfo.pages[0]}-${currentInfo.pages[1]}` : activeSinglePageNum}/100
            </span>
          </div>
        </div>

        {/* Center: Mobile Page Selector (Left / Right / Dual) for Maximum Readability */}
        <div className="flex items-center p-0.5 bg-stone-800 rounded-lg text-[10px] font-medium border border-stone-700">
          <button
            onClick={() => {
              setMobilePageView('left');
            }}
            className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
              mobilePageView === 'left' ? 'bg-[#556B2F] text-white font-bold shadow-2xs' : 'text-stone-400 hover:text-stone-200'
            }`}
            title="Fokus Halaman Kiri (Tracker & Catatan)"
          >
            Kiri (Hal {currentInfo.pages[0]})
          </button>
          <button
            onClick={() => {
              setMobilePageView('right');
            }}
            className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
              mobilePageView === 'right' ? 'bg-[#556B2F] text-white font-bold shadow-2xs' : 'text-stone-400 hover:text-stone-200'
            }`}
            title="Fokus Halaman Kanan (Foto USG & Medis)"
          >
            Kanan (Hal {currentInfo.pages[1]})
          </button>
          <button
            onClick={() => {
              setMobilePageView('both');
            }}
            className={`hidden md:inline-block px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
              mobilePageView === 'both' ? 'bg-[#556B2F] text-white font-bold shadow-2xs' : 'text-stone-400 hover:text-stone-200'
            }`}
            title="Lihat Dua Halaman Berdampingan"
          >
            2 Halaman
          </button>
        </div>

        {/* Right: Sync Indicator, Zoom Controls (desktop) & Hamburger Bar Trigger */}
        <div className="flex items-center gap-1.5">
          {/* Real-time Sync Indicator */}
          <div className="hidden sm:flex items-center gap-1.5 text-[9.5px] text-emerald-400 bg-emerald-950/70 border border-emerald-800/60 px-2 py-0.5 rounded-full">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span>Tersinkron dengan Jurnal</span>
          </div>

          {/* Direct Download PDF Button on Top Bar */}
          <button
            onClick={() => handleTriggerPrint(true)}
            className="px-2.5 py-1 bg-[#556B2F] hover:bg-[#465926] text-white text-[11px] font-semibold rounded-lg flex items-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95"
            title="Download / Simpan Seluruh 100 Halaman ke PDF B5"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Download PDF (B5)</span>
            <span className="sm:hidden">PDF</span>
          </button>

          {/* Zoom In / Out (visible on md+) */}
          <div className="hidden md:flex items-center bg-stone-800 rounded-lg px-1.5 py-0.5 text-stone-300 text-[10px] gap-1">
            <button 
              onClick={() => setZoomScale(z => Math.max(0.4, Number((z - 0.08).toFixed(2))))} 
              className="hover:text-white cursor-pointer p-0.5"
              title="Perkecil"
            >
              <ZoomOut className="w-3 h-3" />
            </button>
            <span className="font-mono text-[9px] w-7 text-center">{Math.round(zoomScale * 100)}%</span>
            <button 
              onClick={() => setZoomScale(z => Math.min(1.2, Number((z + 0.08).toFixed(2))))} 
              className="hover:text-white cursor-pointer p-0.5"
              title="Perbesar"
            >
              <ZoomIn className="w-3 h-3" />
            </button>
          </div>

          {/* Hamburger Bar Button */}
          <button
            onClick={() => setIsMenuOpen(true)}
            className="w-7 h-7 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 hover:text-white flex items-center justify-center transition-colors cursor-pointer shadow-xs active:scale-95 border border-stone-700"
            title="Buka Menu & Pengaturan Cetak"
          >
            <Menu className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* ============================================================== */}
      {/* 2. MAIN VIEWPORT CANVAS (Fitted for mobile readability)        */}
      {/* ============================================================== */}
      <main className="flex-1 overflow-y-auto overflow-x-hidden p-2 sm:p-4 flex flex-col items-center justify-start md:justify-center bg-[#151312] relative print:p-0 print:bg-white print:overflow-visible">
        {printAllMode ? (
          <div className="print-all-container">
            {Array.from({ length: 50 }).map((_, idx) => (
              <div key={idx} className="print-spread mb-8 print:mb-0">
                {renderSpreadContent(idx)}
              </div>
            ))}
          </div>
        ) : (
          <div 
            className={`w-full max-w-[440px] md:max-w-none transition-transform duration-150 origin-top flex items-center justify-center ${
              mobilePageView === 'left' ? 'show-left-only' : 
              mobilePageView === 'right' ? 'show-right-only' : ''
            }`}
            style={{ 
              transform: isMobile ? 'none' : `scale(${zoomScale})`,
              transformOrigin: 'top center',
            }}
          >
            {renderSpreadContent(currentSpreadIndex)}
          </div>
        )}
      </main>

      {/* ============================================================== */}
      {/* 3. BOTTOM BAR: SPREAD STEPPER & LOMPAT BAB BUTTON              */}
      {/* ============================================================== */}
      <footer className="px-3 py-2 sm:px-4 sm:py-2.5 bg-stone-900 border-t border-stone-800 text-white flex items-center justify-between gap-2.5 shrink-0 print:hidden z-20">
        {/* Previous Button */}
        <button
          disabled={currentSpreadIndex === 0}
          onClick={() => setCurrentSpreadIndex(s => Math.max(0, s - 1))}
          className={`px-2.5 py-1.5 sm:px-3 sm:py-1.5 rounded-lg border flex items-center gap-1 text-[11px] font-medium transition-colors cursor-pointer ${
            currentSpreadIndex === 0 
              ? 'opacity-30 cursor-not-allowed border-stone-800 text-stone-600' 
              : 'border-stone-700 bg-stone-800 hover:bg-stone-700 text-stone-200'
          }`}
        >
          <ChevronLeft className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Sebelumnya</span>
        </button>

        {/* Center: Slider & Quick "Lompat Bab" Trigger Button */}
        <div className="flex-1 max-w-sm flex flex-col items-center">
          <div className="flex items-center justify-between w-full text-[10px] text-stone-300 mb-1">
            <button
              onClick={() => setIsBottomChapterOpen(true)}
              className="text-stone-300 hover:text-white font-medium flex items-center gap-1 bg-stone-800 hover:bg-stone-700 px-2 py-0.5 rounded-md border border-stone-700 cursor-pointer"
            >
              <Layers className="w-3 h-3 text-[#556B2F]" />
              <span className="truncate max-w-[120px] sm:max-w-none">{currentInfo.chapterTitle}</span>
              <ChevronUp className="w-3 h-3 text-stone-400" />
            </button>

            <span className="font-mono text-[10px] text-amber-200 shrink-0 ml-1">
              Lembar {currentSpreadIndex + 1}/50
            </span>
          </div>

          <input 
            type="range"
            min="0"
            max="49"
            value={currentSpreadIndex}
            onChange={(e) => setCurrentSpreadIndex(Number(e.target.value))}
            className="w-full accent-[#556B2F] cursor-pointer h-1.5 bg-stone-700 rounded-lg"
          />
        </div>

        {/* Next Button */}
        <button
          disabled={currentSpreadIndex === 49}
          onClick={() => setCurrentSpreadIndex(s => Math.min(49, s + 1))}
          className={`px-2.5 py-1.5 sm:px-3 sm:py-1.5 rounded-lg border flex items-center gap-1 text-[11px] font-medium transition-colors cursor-pointer ${
            currentSpreadIndex === 49 
              ? 'opacity-30 cursor-not-allowed border-stone-800 text-stone-600' 
              : 'border-stone-700 bg-stone-800 hover:bg-stone-700 text-stone-200'
          }`}
        >
          <span className="hidden sm:inline">Berikutnya</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </footer>

      {/* ============================================================== */}
      {/* 4. HAMBURGER SLIDE-OVER DRAWER (Menu, Tema, Bab, Cetak PDF)    */}
      {/* ============================================================== */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex justify-end animate-in fade-in duration-150">
          <div className="bg-[#24211F] text-stone-200 w-full max-w-sm h-full flex flex-col p-4 shadow-2xl border-l border-stone-800 overflow-y-auto no-scrollbar animate-in slide-in-from-right duration-200">
            {/* Drawer Header */}
            <div className="flex items-center justify-between pb-3 border-b border-stone-800 mb-3">
              <div className="flex items-center gap-2">
                <Menu className="w-4 h-4 text-[#556B2F]" />
                <span className="font-serif text-sm font-bold text-white">Menu & Pengaturan B5</span>
              </div>
              <button 
                onClick={() => setIsMenuOpen(false)}
                className="w-7 h-7 rounded-lg bg-stone-800 hover:bg-stone-700 flex items-center justify-center text-stone-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Actions Strip */}
            <div className="space-y-2 mb-4">
              <button
                onClick={() => setIsFillMode(f => !f)}
                className={`w-full p-2.5 rounded-xl border text-left text-xs transition-colors cursor-pointer flex items-center justify-between ${
                  isFillMode ? 'bg-[#556B2F]/20 border-[#556B2F]/50 text-white' : 'bg-stone-800 border-stone-700 text-stone-300'
                }`}
              >
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-amber-300 shrink-0" />
                  <div>
                    <span className="font-bold block text-[11px]">{isFillMode ? 'Mode Jurnal: Data Terisi' : 'Mode Jurnal: Kosong (Tulis Tangan)'}</span>
                    <span className="text-[9.5px] text-stone-400 block">{isFillMode ? 'Menampilkan teks & data kehamilan' : 'Format bergaris bersih siap tulis tangan'}</span>
                  </div>
                </div>
                <span className="text-xs font-mono font-bold text-[#708846]">{isFillMode ? 'ON' : 'OFF'}</span>
              </button>

              <div className="p-2.5 rounded-xl bg-stone-800/80 border border-stone-700 text-[10px] text-stone-300 flex items-start gap-2">
                <span className="text-base leading-none">✍️</span>
                <div>
                  <strong className="text-white block font-medium">Bisa Diedit Langsung</strong>
                  <span>Ketuk kolom mana saja di halaman buku untuk mengisi atau mengubah data yang masih kurang.</span>
                </div>
              </div>
            </div>

            {/* Download Entire 100 Pages or Current Spread PDF Action */}
            <div className="space-y-2 mb-4">
              <button
                onClick={() => {
                  setIsMenuOpen(false);
                  handleTriggerPrint(true);
                }}
                className="w-full py-3 bg-[#556B2F] hover:bg-[#465926] text-white font-semibold rounded-xl text-xs flex items-center justify-center gap-2 shadow-md transition-all active:scale-98 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Download Seluruh Buku (100 Halaman PDF B5)</span>
              </button>

              <button
                onClick={() => {
                  setIsMenuOpen(false);
                  handleTriggerPrint(false);
                }}
                className="w-full py-2 bg-stone-850 hover:bg-stone-800 text-stone-200 border border-stone-700 font-medium rounded-xl text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5 text-stone-400" />
                <span>Download Lembar Ini Saja (Hal {currentInfo.pages[0]}-{currentInfo.pages[1]})</span>
              </button>
            </div>

            {/* 5 Theme Switcher */}
            <div className="mb-4">
              <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400 flex items-center gap-1.5 mb-2">
                <Palette className="w-3.5 h-3.5 text-[#556B2F]" />
                Pilihan Tema B5 (Format Tetap Sama)
              </span>
              <div className="space-y-1.5">
                {Object.values(BOOK_THEMES).map((thm) => (
                  <button
                    key={thm.id}
                    onClick={() => {
                      setSelectedThemeId(thm.id);
                    }}
                    className={`w-full p-2 rounded-xl text-left flex items-center justify-between border transition-all cursor-pointer ${
                      selectedThemeId === thm.id
                        ? 'bg-stone-800 border-white text-white shadow-xs font-semibold'
                        : 'bg-stone-850 border-stone-800 text-stone-400 hover:bg-stone-800 hover:text-stone-200'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-3 h-3 rounded-full shrink-0 border border-white/20" style={{ backgroundColor: thm.swatchHex }} />
                      <div>
                        <p className="text-xs">{thm.name}</p>
                        <p className="text-[9px] text-stone-400 font-light truncate max-w-[200px]">{thm.subtitle}</p>
                      </div>
                    </div>
                    {selectedThemeId === thm.id && <span className="text-xs text-[#556B2F] font-bold">✓</span>}
                  </button>
                ))}
              </div>
            </div>

            {/* Lompat Bab Section */}
            <div className="mt-auto pt-3 border-t border-stone-800">
              <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400 flex items-center gap-1.5 mb-2">
                <Layers className="w-3.5 h-3.5 text-[#556B2F]" />
                Daftar Bab & Halaman
              </span>
              <div className="space-y-1 max-h-56 overflow-y-auto no-scrollbar">
                {BOOK_CHAPTERS.map((ch) => {
                  const startSpread = Math.floor((ch.pageStart - 1) / 2);
                  const endSpread = Math.floor((ch.pageEnd - 1) / 2);
                  const isActive = currentSpreadIndex >= startSpread && currentSpreadIndex <= endSpread;

                  return (
                    <button
                      key={ch.id}
                      onClick={() => {
                        setCurrentSpreadIndex(startSpread);
                        setIsMenuOpen(false);
                      }}
                      className={`w-full p-2 rounded-xl text-left flex items-center justify-between text-xs transition-colors cursor-pointer ${
                        isActive ? 'bg-[#556B2F] text-white font-bold' : 'hover:bg-stone-800 text-stone-300'
                      }`}
                    >
                      <div className="truncate mr-2">
                        <p className="truncate text-[11px]">{ch.title}</p>
                        <p className="text-[9px] opacity-70 truncate font-light">{ch.description}</p>
                      </div>
                      <span className="font-mono text-[10px] opacity-80 shrink-0">
                        Hal {ch.pageStart}-{ch.pageEnd}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 5. BOTTOM SHEET: LOMPAT BAB LANGSUNG DARI BAWAH               */}
      {/* ============================================================== */}
      {isBottomChapterOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-end justify-center p-0 animate-in fade-in duration-150">
          <div className="bg-[#24211F] text-stone-200 w-full max-w-lg rounded-t-3xl p-4 shadow-2xl border-t border-stone-700 max-h-[80vh] flex flex-col animate-in slide-in-from-bottom duration-200">
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-stone-800">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#556B2F]" />
                <span className="font-serif text-sm font-bold text-white">Lompat ke Bab Buku</span>
              </div>
              <button 
                onClick={() => setIsBottomChapterOpen(false)}
                className="w-7 h-7 rounded-full bg-stone-800 flex items-center justify-center text-stone-400 hover:text-white cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="overflow-y-auto no-scrollbar space-y-1.5 py-1">
              {BOOK_CHAPTERS.map((ch) => {
                const startSpread = Math.floor((ch.pageStart - 1) / 2);
                const endSpread = Math.floor((ch.pageEnd - 1) / 2);
                const isActive = currentSpreadIndex >= startSpread && currentSpreadIndex <= endSpread;

                return (
                  <button
                    key={ch.id}
                    onClick={() => {
                      setCurrentSpreadIndex(startSpread);
                      setIsBottomChapterOpen(false);
                    }}
                    className={`w-full p-2.5 rounded-2xl text-left flex items-center justify-between border transition-all cursor-pointer ${
                      isActive 
                        ? 'bg-[#556B2F] border-[#556B2F] text-white shadow-xs font-semibold' 
                        : 'bg-stone-850 border-stone-800 text-stone-300 hover:bg-stone-800'
                    }`}
                  >
                    <div className="truncate mr-2">
                      <p className="text-xs font-bold">{ch.title}</p>
                      <p className="text-[10px] opacity-75 truncate">{ch.description}</p>
                    </div>
                    <span className="font-mono text-[10px] bg-black/30 px-2 py-0.5 rounded-md shrink-0">
                      Hal {ch.pageStart}-{ch.pageEnd}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
